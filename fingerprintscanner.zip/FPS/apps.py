from django.apps import AppConfig


class FpsConfig(AppConfig):
    name = 'FPS'
